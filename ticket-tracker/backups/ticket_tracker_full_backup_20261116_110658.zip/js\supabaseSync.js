/**
 * supabaseSync.js - Realtime Cloud Synchronization with Supabase
 * Memungkinkan sinkronisasi instan antara Laptop dan HP secara realtime!
 */

const SYNC_STORAGE_KEYS = {
  SUPABASE_URL: 'tt_supabase_url',
  SUPABASE_KEY: 'tt_supabase_anon_key',
  REALTIME_ACTIVE: 'tt_realtime_active'
};

class SupabaseSyncManager {
  constructor() {
    this.client = null;
    this.channel = null;
    this.isConnected = false;
    this.isSyncing = false;
    this.init();
  }

  init() {
    const url = localStorage.getItem(SYNC_STORAGE_KEYS.SUPABASE_URL);
    const key = localStorage.getItem(SYNC_STORAGE_KEYS.SUPABASE_KEY);

    if (url && key && typeof window.supabase !== 'undefined') {
      try {
        this.client = window.supabase.createClient(url, key);
        this.connectRealtime();
      } catch (err) {
        console.error('Supabase init failed:', err);
      }
    }
  }

  getConfig() {
    return {
      url: localStorage.getItem(SYNC_STORAGE_KEYS.SUPABASE_URL) || '',
      key: localStorage.getItem(SYNC_STORAGE_KEYS.SUPABASE_KEY) || '',
      isActive: localStorage.getItem(SYNC_STORAGE_KEYS.REALTIME_ACTIVE) === 'true'
    };
  }

  async saveConfig(url, key) {
    url = (url || '').trim();
    key = (key || '').trim();

    localStorage.setItem(SYNC_STORAGE_KEYS.SUPABASE_URL, url);
    localStorage.setItem(SYNC_STORAGE_KEYS.SUPABASE_KEY, key);
    localStorage.setItem(SYNC_STORAGE_KEYS.REALTIME_ACTIVE, (url && key) ? 'true' : 'false');

    if (url && key && typeof window.supabase !== 'undefined') {
      this.client = window.supabase.createClient(url, key);
      return await this.testAndSync();
    } else {
      this.disconnect();
      return { success: false, message: 'Kredensial kosong. Menggunakan mode lokal.' };
    }
  }

  async testAndSync() {
    if (!this.client) {
      return { success: false, message: 'Library Supabase belum termuat.' };
    }

    try {
      // Test read 1 row
      const { data, error } = await this.client.from('tickets').select('id').limit(1);
      if (error) {
        throw error;
      }

      this.isConnected = true;
      this.connectRealtime();
      await this.pullFromCloud();

      return { success: true, message: 'Berhasil terhubung ke Supabase Realtime Cloud!' };
    } catch (err) {
      console.error('Supabase connection test failed:', err);
      this.isConnected = false;
      return { success: false, message: 'Gagal terhubung: ' + (err.message || 'Periksa URL dan Anon Key.') };
    }
  }

  // Tarik semua data dari cloud saat pertama kali buka web di HP / Laptop
  async pullFromCloud() {
    if (!this.client) return false;

    try {
      this.isSyncing = true;
      const { data, error } = await this.client
        .from('tickets')
        .select('*')
        .order('updated_at', { ascending: false });

      if (error) throw error;

      if (data && data.length > 0) {
        // Konversi format kolom database ke format internal camelCase
        const formatted = data.map(row => ({
          id: row.id,
          no: row.no,
          vendor: row.vendor,
          sow: row.sow,
          province: row.province,
          kabupaten: row.kabupaten,
          towerId: row.tower_id,
          siteId: row.site_id,
          siteName: row.site_name,
          hostnameCsr: row.hostname_csr,
          ipLoopback: row.ip_loopback,
          directMwFo: row.direct_mw_fo,
          mop: row.mop,
          planActivity: row.plan_activity,
          dateSubmit: row.date_submit,
          xlwoTitle: row.xlwo_title,
          xlwoNum: row.xlwo_num,
          rfcNum: row.rfc_num,
          status: row.status,
          notes: row.notes,
          updatedAt: row.updated_at
        }));

        // Simpan ke local storage tanpa membuat auto-snapshot berulang
        window.appStorage.saveTickets(formatted, false);
        if (window.ticketTracker) window.ticketTracker.refresh();
        if (typeof window.refreshDashboardUI === 'function') {
          window.refreshDashboardUI();
        }
      }
      return true;
    } catch (e) {
      console.error('Pull from cloud error:', e);
      return false;
    } finally {
      this.isSyncing = false;
      this.updateCloudStatusIndicator();
    }
  }

  // Upload satu atau banyak tiket ke Supabase Cloud
  async pushTickets(tickets) {
    if (!this.client || !this.isConnected) return false;

    try {
      const dbRows = tickets.map(t => ({
        id: t.id,
        no: t.no || '',
        vendor: t.vendor || '',
        sow: t.sow || '',
        province: t.province || '',
        kabupaten: t.kabupaten || '',
        tower_id: t.towerId || '',
        site_id: t.siteId || '',
        site_name: t.siteName || '',
        hostname_csr: t.hostnameCsr || '',
        ip_loopback: t.ipLoopback || '',
        direct_mw_fo: t.directMwFo || '',
        mop: t.mop || '',
        plan_activity: t.planActivity || '',
        date_submit: t.dateSubmit || '',
        xlwo_title: t.xlwoTitle || '',
        xlwo_num: t.xlwoNum || '',
        rfc_num: t.rfcNum || '',
        status: t.status || 'partial',
        notes: t.notes || '',
        updated_at: t.updatedAt || new Date().toISOString()
      }));

      // Upsert batch (maks 100 per chunk agar aman)
      const chunkSize = 100;
      for (let i = 0; i < dbRows.length; i += chunkSize) {
        const chunk = dbRows.slice(i, i + chunkSize);
        const { error } = await this.client.from('tickets').upsert(chunk, { onConflict: 'id' });
        if (error) throw error;
      }

      return true;
    } catch (err) {
      console.error('Push to cloud error:', err);
      return false;
    }
  }

  // Dengarkan perubahan realtime dari device lain via WebSockets
  connectRealtime() {
    if (!this.client) return;

    if (this.channel) {
      this.channel.unsubscribe();
    }

    this.channel = this.client
      .channel('public:tickets')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tickets' }, (payload) => {
        this.handleRealtimeEvent(payload);
      })
      .subscribe((status) => {
        this.isConnected = (status === 'SUBSCRIBED');
        this.updateCloudStatusIndicator();
      });
  }

  handleRealtimeEvent(payload) {
    const { eventType, new: newRow, old: oldRow } = payload;
    let localTickets = window.appStorage.getTickets();

    if (eventType === 'INSERT' || eventType === 'UPDATE') {
      const formatted = {
        id: newRow.id,
        no: newRow.no,
        vendor: newRow.vendor,
        sow: newRow.sow,
        province: newRow.province,
        kabupaten: newRow.kabupaten,
        towerId: newRow.tower_id,
        siteId: newRow.site_id,
        siteName: newRow.site_name,
        hostnameCsr: newRow.hostname_csr,
        ipLoopback: newRow.ip_loopback,
        directMwFo: newRow.direct_mw_fo,
        mop: newRow.mop,
        planActivity: newRow.plan_activity,
        dateSubmit: newRow.date_submit,
        xlwoTitle: newRow.xlwo_title,
        xlwoNum: newRow.xlwo_num,
        rfcNum: newRow.rfc_num,
        status: newRow.status,
        notes: newRow.notes,
        updatedAt: newRow.updated_at
      };

      const idx = localTickets.findIndex(t => t.id === formatted.id);
      if (idx >= 0) {
        localTickets[idx] = formatted;
      } else {
        localTickets.unshift(formatted);
      }

      window.appStorage.saveTickets(localTickets, false);
      if (window.ticketTracker) window.ticketTracker.refresh();
      if (typeof window.refreshDashboardUI === 'function') {
        window.refreshDashboardUI();
      }

      if (typeof window.showToast === 'function') {
        window.showToast(`⚡ Realtime Update: Site "${formatted.siteName}" diperbarui dari device lain!`, 'info');
      }
    } else if (eventType === 'DELETE') {
      localTickets = localTickets.filter(t => t.id !== oldRow.id);
      window.appStorage.saveTickets(localTickets, false);
      if (window.ticketTracker) window.ticketTracker.refresh();
      if (typeof window.refreshDashboardUI === 'function') {
        window.refreshDashboardUI();
      }
    }
  }

  disconnect() {
    if (this.channel) {
      this.channel.unsubscribe();
      this.channel = null;
    }
    this.client = null;
    this.isConnected = false;
    this.updateCloudStatusIndicator();
  }

  updateCloudStatusIndicator() {
    const el = document.getElementById('cloud-sync-status');
    if (!el) return;

    if (this.isConnected) {
      el.innerHTML = `<span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#10b981; margin-right:5px; box-shadow: 0 0 6px #10b981;"></span> Realtime Cloud: Aktif`;
      el.style.borderColor = 'rgba(16, 185, 129, 0.4)';
      el.style.color = '#10b981';
    } else {
      const cfg = this.getConfig();
      if (cfg.url) {
        el.innerHTML = `<span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#f59e0b; margin-right:5px;"></span> Menghubungkan Cloud...`;
        el.style.borderColor = 'rgba(245, 158, 11, 0.4)';
        el.style.color = '#f59e0b';
      } else {
        el.innerHTML = `<span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#64748b; margin-right:5px;"></span> Mode Lokal (Offline)`;
        el.style.borderColor = 'var(--border-color)';
        el.style.color = 'var(--text-muted)';
      }
    }
  }

  static getSqlSetupScript() {
    return `-- ==========================================================
-- SCRIPT SQL SUPABASE UNTUK TRACKER TIKET REALTIME
-- Salin dan Paste ini ke SQL Editor di dashboard Supabase kamu
-- ==========================================================

-- 1. Buat Tabel Tiket
create table if not exists public.tickets (
  id text primary key,
  no text,
  vendor text,
  sow text,
  province text,
  kabupaten text,
  tower_id text,
  site_id text,
  site_name text,
  hostname_csr text,
  ip_loopback text,
  direct_mw_fo text,
  mop text,
  plan_activity text,
  date_submit text,
  xlwo_title text,
  xlwo_num text,
  rfc_num text,
  status text default 'partial',
  notes text,
  updated_at timestamptz default now()
);

-- 2. Aktifkan Realtime WebSockets untuk tabel ini
alter publication supabase_realtime add table public.tickets;

-- 3. Buka Akses RLS untuk Personal App
alter table public.tickets enable row level security;
create policy "Akses Penuh Tiket Personal" on public.tickets for all using (true) with check (true);
`;
  }
}

window.supabaseSync = new SupabaseSyncManager();
