# 📡 Ticket Tracker & NOC Realtime Dashboard

Aplikasi web personal untuk tracking tiket **XLWO & RFC**, monitoring masa berlaku SLA & reminder dini, mengelola status site (`done`, `partial`, `pending`), dan siap dikembangkan untuk integrasi data realtime di masa mendatang.

Dirancang **mobile-first** sehingga bisa langsung dibuka di browser HP (Chrome, Safari, Firefox) tanpa perlu install aplikasi Android APK.

---

## 🚀 Cara Menjalankan

### Cara 1: Menggunakan Local Web Server (Bisa Dibuka di HP)
1. Buka folder project: `C:\Users\andiy\.gemini\antigravity\scratch\ticket-tracker`
2. Klik ganda (double-click) file **`run_server.bat`** (atau jalankan `powershell -File start-server.ps1`).
3. Server otomatis berjalan dan menampilkan alamat:
   - **Di Laptop:** [http://localhost:8080](http://localhost:8080)
   - **Di HP (Wi-Fi sama):** `http://192.168.18.62:8080` *(atau sesuaikan dengan IP Wi-Fi laptop kamu)*
4. **Tips di HP:** Di browser HP (misal Chrome), buka menu titik tiga (⋮) lalu pilih **"Add to Home screen"** / **"Tambahkan ke layar utama"** agar tampil seperti aplikasi native tanpa install APK!

### Cara 2: Langsung Buka File HTML (Offline di Laptop)
Cukup klik ganda file **`index.html`** di browser Chrome/Edge/Firefox mana saja. Semua fitur tetap berfungsi penuh (data tersimpan di browser LocalStorage).

---

## 📋 Fitur Utama & Logika Sistem

### 1. Ekstraksi Tanggal & Aturan SLA Reminder
Tanggal pembuatan tiket diambil otomatis dari format nomor tiket:
- Format: `XLWO-YYYYMMDD-XXXXXXXX` dan `RFC-YYYYMMDD-XXXXXXXX`
  - Contoh: `XLWO-20261110-00000035` ➔ Tanggal Buat: **10 Nov 2026**
  - Contoh: `RFC-20261110-00000023` ➔ Tanggal Buat: **10 Nov 2026**

**Aturan Hitungan:**
| Jenis Tiket | Masa Berlaku | Batas Mulai Reminder | Indikator Status |
| :--- | :--- | :--- | :--- |
| **XLWO** | **7 Hari** | **H-5 sebelum Expire** *(sisa ≤ 5 hari)* | 🟢 Aman (> 5 hari)<br>🟡 **Reminder H-5** (≤ 5 hari)<br>🔴 **Kritis** (≤ 2 hari)<br>⚫ **Expired** (≤ 0 hari) |
| **RFC** | **27 Hari** | **H-25 sebelum Expire** *(sisa ≤ 25 hari)* | 🟢 Aman (> 25 hari)<br>🟡 **Reminder H-25** (≤ 25 hari)<br>🔴 **Kritis** (≤ 5 hari)<br>⚫ **Expired** (≤ 0 hari) |

> ⚙️ Nilai hari masa berlaku dan batas reminder ini dapat kamu ubah kapan saja melalui tab **"SLA & Reminder"** di aplikasi.

---

### 2. Multi-Site & Penanganan Status Partial
Satu nomor `XLWO` dan `RFC` yang sama dapat memiliki beberapa baris site dengan status berbeda (contoh: site 1 `done`, site 2 `partial`).
- Sistem mengelompokkan baris berdasarkan nomor tiket yang sama.
- Tampil kartu ringkasan tiket lengkap dengan badge **"⚠️ Ada Partial - Perlu Lanjutan"**.
- Kamu bisa klik tombol **"✏️ Status"** pada site tertentu untuk mengubah statusnya (misal dari `partial` ke `done`) atau menambahkan catatan progress.

---

### 3. Update Data via Excel / Paste Langsung
Tersedia 2 cara update data:
1. **📋 Paste Langsung dari Excel:**
   - Blok tabel di Excel (termasuk baris header), tekan `Ctrl+C`.
   - Di web, klik tombol **"Paste Excel"** di kanan atas, tekan `Ctrl+V`, lalu klik **"Proses"**.
2. **📤 Upload File (.xlsx / .csv):**
   - Drag & drop atau pilih file `.xlsx` / `.csv`.
   - Pilih metode **Smart Merge** (mengupdate site yang ada & menambahkan data baru tanpa menghapus catatan lama) atau **Overwrite** (ganti total).
3. **📄 Download Template:**
   - Tersedia tombol **"Template"** untuk mengunduh template CSV dengan nama kolom yang sesuai.

---

### 4. Backup & Rollback Aman
- **Backup Data (JSON):** Tab **Backup & Snapshot** ➔ klik **"Download Backup (JSON)"** untuk menyimpan seluruh data & pengaturan.
- **Restore Data:** Klik **"Restore dari File JSON"** kapan saja.
- **Auto-Snapshot (Safety Rollback):** Setiap kali kamu upload data baru atau ubah status, sistem otomatis menyimpan snapshot riwayat (hingga 10 snapshot terakhir). Jika salah import, cukup klik **"Rollback ke Sini"**!
- **Backup Source Code Project (.zip):** Klik ganda file **`backup_project.bat`** (atau jalankan `powershell -File backup-project.ps1`). Script akan otomatis membuat file zip berstempel waktu di folder `backups/`.

---

### 5. Modul Siap Realtime (Extensible)
Tab **"Realtime Monitor"** sudah disiapkan sebagai fondasi jika kamu ingin menambahkan data stream telemetry, latency CSR, IP Loopback status, dan BGP status di masa mendatang.
- Modul berada di `js/realtimeData.js`.
- Mendukung simulasi live stream atau integrasi API/JSON update berkala.

---

## 📁 Struktur Folder Project
```text
ticket-tracker/
├── index.html              # Antarmuka web utama (responsif mobile & desktop)
├── run_server.bat          # 1-klik jalankan server lokal untuk dibuka di HP
├── start-server.ps1        # Script server HTTP native PowerShell (tanpa dependency)
├── backup_project.bat      # 1-klik backup seluruh source code ke file .zip
├── backup-project.ps1      # Script PowerShell backup kode
├── README.md               # Dokumentasi lengkap
├── css/
│   └── app.css             # Desain NOC modern, dark/light theme, mobile drawer
├── js/
│   ├── app.js              # Controller utama & interaksi UI
│   ├── storage.js          # Penyimpanan LocalStorage & Auto-Snapshot
│   ├── ticketTracker.js    # Perhitungan SLA, parser tanggal, pengelompokan tiket
│   ├── backupManager.js    # Export/Import JSON, CSV, dan template
│   └── realtimeData.js     # Modul extensible untuk data realtime
├── data/
│   └── sample_data.csv     # Contoh data awal sesuai format kamu
└── backups/                # Folder tempat file .zip backup kode tersimpan
```
